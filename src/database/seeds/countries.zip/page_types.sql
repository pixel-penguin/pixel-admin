insert into `page_types` (`id`, `user_id`, `name`, `view_blade_name`, `created_at`, `updated_at`) values('1','1','Detail & Gallery','website.page.detail_gallery',NULL,NULL);
insert into `page_types` (`id`, `user_id`, `name`, `view_blade_name`, `created_at`, `updated_at`) values('2','1','Gallery','website.page.gallery',NULL,NULL);
insert into `page_types` (`id`, `user_id`, `name`, `view_blade_name`, `created_at`, `updated_at`) values('3','1','Page Builder','website.page.page_builder',NULL,NULL);
insert into `page_types` (`id`, `user_id`, `name`, `view_blade_name`, `created_at`, `updated_at`) values('4','1','Detail with Subpages','website.page.detail_subpages',NULL,NULL);
insert into `page_types` (`id`, `user_id`, `name`, `view_blade_name`, `created_at`, `updated_at`) values('5','1','Accommodation','website.page.accommodation',NULL,NULL);
insert into `page_types` (`id`, `user_id`, `name`, `view_blade_name`, `created_at`, `updated_at`) values('6','1','Products','website.page.product',NULL,NULL);
insert into `page_types` (`id`, `user_id`, `name`, `view_blade_name`, `created_at`, `updated_at`) values('7','1','Home Page','website.page.home',NULL,NULL);
