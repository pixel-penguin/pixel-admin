<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        //$this->call(AdminNavigationSeeder::class);
		DB::unprepared(file_get_contents(__DIR__ . '\admin_navigation.sql'));
        //DB::unprepared(file_get_contents(__DIR__ . '\countries.sql'));
        //DB::unprepared(file_get_contents(__DIR__ . '\states.sql'));
        //DB::unprepared(file_get_contents(__DIR__ . '\cities.sql'));
        DB::unprepared(file_get_contents(__DIR__ . '\mobile_page_content_types.sql'));
        DB::unprepared(file_get_contents(__DIR__ . '\page_content_types.sql'));
        DB::unprepared(file_get_contents(__DIR__ . '\page_types.sql'));
    }
}
