insert into `mobile_page_content_types` (`id`, `name`, `icon_name`, `active`, `created_at`, `updated_at`) values('1','Text Only','pixel-penguin-cms/icons/page-builder/basic','1',NULL,NULL);
insert into `mobile_page_content_types` (`id`, `name`, `icon_name`, `active`, `created_at`, `updated_at`) values('2','Cover Image','pixel-penguin-cms/icons/page-builder/cover','0',NULL,NULL);
insert into `mobile_page_content_types` (`id`, `name`, `icon_name`, `active`, `created_at`, `updated_at`) values('3','2 Images','pixel-penguin-cms/icons/page-builder/2_picture_1','0',NULL,NULL);
insert into `mobile_page_content_types` (`id`, `name`, `icon_name`, `active`, `created_at`, `updated_at`) values('4','Button','pixel-penguin-cms/icons/page-builder/link_button-01','1',NULL,NULL);
insert into `mobile_page_content_types` (`id`, `name`, `icon_name`, `active`, `created_at`, `updated_at`) values('5','Gallery','pixel-penguin-cms/icons/page-builder/gallery','1',NULL,NULL);
insert into `mobile_page_content_types` (`id`, `name`, `icon_name`, `active`, `created_at`, `updated_at`) values('6','Video','pixel-penguin-cms/icons/page-builder/video','0',NULL,NULL);
insert into `mobile_page_content_types` (`id`, `name`, `icon_name`, `active`, `created_at`, `updated_at`) values('7','Image Left &amp; Text Right','pixel-penguin-cms/icons/page-builder/cms_images-01','0',NULL,NULL);
insert into `mobile_page_content_types` (`id`, `name`, `icon_name`, `active`, `created_at`, `updated_at`) values('8','Image Right &amp; Text Left','pixel-penguin-cms/icons/page-builder/image_right_text_left-01','0',NULL,NULL);
